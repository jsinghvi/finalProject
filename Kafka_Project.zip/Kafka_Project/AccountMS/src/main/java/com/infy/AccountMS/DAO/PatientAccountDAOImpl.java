package com.infy.AccountMS.DAO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Repository;

import com.infy.AccountMS.entity.AccountEntity;
import com.infy.AccountMS.model.Account;

@Repository
public class PatientAccountDAOImpl implements PatientAccountDAO {

	@PersistenceContext
	EntityManager entityManager;


	@Override
	public Account getAccountDetails(Integer personId) throws Exception {
		// TODO Auto-generated method stub
		AccountEntity accountEntity = entityManager.find(AccountEntity.class, personId);
		if (accountEntity == null) {
			return null;
		}
		Account account = new Account();
		account.setPersonId(personId);
		account.setDepartment(accountEntity.getDepartment());
		account.setDesg(accountEntity.getDesg());
		account.setSalary(accountEntity.getSalary());
		return account;
	}

}
