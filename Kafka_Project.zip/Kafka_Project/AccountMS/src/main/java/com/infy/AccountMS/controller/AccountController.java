package com.infy.AccountMS.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infy.AccountMS.model.Account;
import com.infy.AccountMS.service.PatientAccountService;

@RestController
@CrossOrigin
public class AccountController {

	@Autowired
	PatientAccountService patientAccountService;

	Logger logger = LogManager.getLogger(this.getClass());

	@RequestMapping(value = "/account/{personId}", method = RequestMethod.GET)
	public Account getDetails(@PathVariable Integer personId) {
		Account account = new Account();
		try {
			if (personId == null) {
				logger.error("Controller receives PersonID as NULL!!");
				return null;
			}
			account = patientAccountService.getAccountDetails(personId);
			if (account == null) {
				logger.error("No Data found for given person id");
				account.setPersonId(-1);
			}
		} catch (Exception e) {

			logger.error(e.getMessage());
		}
		return account;
	}

}
