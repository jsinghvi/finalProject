package com.infy.AccountMS.DAO;

import com.infy.AccountMS.model.Account;

public interface PatientAccountDAO {
	public Account getAccountDetails(Integer personId) throws Exception;
}
