package com.infy.AccountMS.service;

import com.infy.AccountMS.model.Account;

public interface PatientAccountService {
	public Account getAccountDetails(Integer personId) throws Exception;
}
