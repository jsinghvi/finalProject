package com.infy.AccountMS.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.infy.AccountMS.DAO.PatientAccountDAO;
import com.infy.AccountMS.model.Account;

@Service
@Transactional
public class PatientAccountServiceImpl implements PatientAccountService {

	@Autowired
	PatientAccountDAO patientAccountDAO;

	Logger logger = LogManager.getLogger(this.getClass());

	@Override
	public Account getAccountDetails(Integer personId) throws Exception {
		// TODO Auto-generated method stub
		Account accountToReturn = patientAccountDAO.getAccountDetails(personId);
		if (accountToReturn == null) {
			return null;
		}
		return accountToReturn;
	}

}
