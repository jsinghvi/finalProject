package com.infy.consumer.stream;

import org.springframework.cloud.stream.annotation.EnableBinding;

@EnableBinding(ProducerDataStream.class)
public class StreamConfig {

}
