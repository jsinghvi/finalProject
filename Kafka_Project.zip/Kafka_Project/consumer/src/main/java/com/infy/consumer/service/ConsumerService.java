package com.infy.consumer.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infy.consumer.dao.ConsumerDao;
import com.infy.consumer.model.Account;
import com.infy.consumer.model.Patient;


@Service
public class ConsumerService {
	
	@Autowired
	ConsumerDao consumerDao;

	
	public int consume(Patient patient) {
		Logger logger = LoggerFactory.getLogger(this.getClass());
		try {

			logger.info("Data received from Producer " + patient);
			
			Patient patientNew = new Patient();
			patientNew.setAddress(patient.getAddress());
			patientNew.setFirstName(patient.getFirstName());
			patientNew.setLastName(patient.getLastName());
			patientNew.setPersonId(patient.getPersonId());
			patientNew.setPhoneNo(patient.getPhoneNo());
			
			consumerDao.savePatient(patientNew);
					
		} catch (Exception e) {
			System.out.println(e.getMessage());
			logger.error("Exception occured in consumer " + e.getMessage());
		}
		return patient.getPersonId();

	}
	
	
	public Integer saveRecord(Account account) throws Exception {
		
		String str=consumerDao.saveRecord(account.getPersonId());
		
		return account.getPersonId();

	}
}
