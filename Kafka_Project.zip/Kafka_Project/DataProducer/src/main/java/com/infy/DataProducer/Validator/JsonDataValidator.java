package com.infy.DataProducer.Validator;

import org.json.simple.JSONObject;

public class JsonDataValidator {

	public int DataValidator(JSONObject jsonData) {
		if (jsonData.get("personId") == null || jsonData.get("firstName") == null || jsonData.get("lastName") == null
				|| jsonData.get("phoneNo") == null || jsonData.get("address") == null) {
			return 0;
		}
		return 1;
	}

}
