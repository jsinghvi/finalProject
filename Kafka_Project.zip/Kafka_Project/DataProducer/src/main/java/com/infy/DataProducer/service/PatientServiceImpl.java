package com.infy.DataProducer.service;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import com.infy.DataProducer.Validator.JsonDataValidator;
import com.infy.DataProducer.dao.PatientDao;
import com.infy.DataProducer.model.Patient;

@Service
public class PatientServiceImpl implements PatientService {
	
	@Autowired
	PatientSendData patientSendData;
	
	@Autowired
	PatientDao patientDao;

	@Override
	public void checkPatientData(JSONObject jsonData) throws Exception {
		JsonDataValidator jsonDataValidator = new JsonDataValidator();
		int check = jsonDataValidator.DataValidator(jsonData);
		if (check == 0)
			throw new Exception("All fields are not present in JSON File");
		Patient patient = JsonDataToModel(jsonData);
		patientSendData.sendDataToKafka(patient);

	}

	@Override
	public Patient JsonDataToModel(JSONObject jsonData) throws Exception {
		Patient patient = new Patient();
		patient.setPersonId(Integer.parseInt(jsonData.get("personId").toString()));
		patient.setFirstName((String) jsonData.get("firstName"));
		patient.setLastName((String) jsonData.get("lastName"));
		JSONArray jsonArray = (JSONArray) jsonData.get("address");
		String[] addressArray = new String[jsonArray.size()];
		for (int i = 0; i < jsonArray.size(); i++) {
			addressArray[i] = jsonArray.get(i).toString();
		}
		patient.setAddress(addressArray);
		JSONArray jsonArrayForPhone = (JSONArray) jsonData.get("phoneNo");
		System.out.println(jsonArrayForPhone);
		Long[] phoneArray = new Long[jsonArrayForPhone.size()];
		for (int i = 0; i < jsonArrayForPhone.size(); i++) {
			phoneArray[i] = Long.parseLong(jsonArrayForPhone.get(i).toString());
		}
		patient.setPhoneNo(phoneArray);
		return patient;
	}

	@Override
	public void readJsonData() throws Exception {
		JSONObject jsonData= patientDao.readJsonData();
		checkPatientData(jsonData);
		
	}

}
