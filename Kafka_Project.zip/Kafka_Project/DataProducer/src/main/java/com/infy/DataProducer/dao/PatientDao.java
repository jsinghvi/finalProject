package com.infy.DataProducer.dao;

import org.json.simple.JSONObject;

public interface PatientDao {
	public JSONObject readJsonData() throws Exception;
}
