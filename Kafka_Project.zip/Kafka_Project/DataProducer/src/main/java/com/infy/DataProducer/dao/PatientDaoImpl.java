package com.infy.DataProducer.dao;

import java.io.FileReader;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository
public class PatientDaoImpl implements PatientDao {

	Logger logger = LoggerFactory.getLogger(this.getClass());
	@Override
	public JSONObject readJsonData() throws Exception {

		Object jsonFileData = new JSONParser().parse(new FileReader(
				"C:\\Users\\ayush.goel05\\Downloads\\DataProducer\\DataProducer\\src\\main\\resources\\patient1.json"));
		if(jsonFileData == null)
		{
			throw new Exception("JSON file is empty");
			
		}
		return (JSONObject) jsonFileData;

	}

}
