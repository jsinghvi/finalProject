package com.infy.DataProducer.service;

import com.infy.DataProducer.model.Patient;

public interface PatientSendData {
	public void sendDataToKafka(final Patient patient) throws Exception;
}
