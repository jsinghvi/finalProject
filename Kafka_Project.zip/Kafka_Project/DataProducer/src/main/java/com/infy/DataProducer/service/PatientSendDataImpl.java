package com.infy.DataProducer.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHeaders;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Service;
import org.springframework.util.MimeTypeUtils;

import com.infy.DataProducer.model.Patient;
import com.infy.DataProducer.stream.ProducerDataStream;

@Service
public class PatientSendDataImpl implements PatientSendData {
	private final ProducerDataStream producerDataStream;
	Logger logger = LoggerFactory.getLogger(this.getClass());

	public PatientSendDataImpl(ProducerDataStream producerDataStream) {
		this.producerDataStream = producerDataStream;
	}

	@Override
	public void sendDataToKafka(final Patient patient) throws Exception {
		logger.info("Data sended ---- "+patient);
		MessageChannel messageChannel = producerDataStream.outboundGreetings();
		messageChannel.send(MessageBuilder.withPayload(patient)
				.setHeader(MessageHeaders.CONTENT_TYPE, MimeTypeUtils.APPLICATION_JSON).build());

	}

}
