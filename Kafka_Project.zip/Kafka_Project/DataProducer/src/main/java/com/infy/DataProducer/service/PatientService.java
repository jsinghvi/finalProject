package com.infy.DataProducer.service;

import org.json.simple.JSONObject;

import com.infy.DataProducer.model.Patient;

public interface PatientService {

	public void checkPatientData(JSONObject jsonData) throws Exception;

	public Patient JsonDataToModel(JSONObject jsonData) throws Exception;
	
	public void readJsonData() throws Exception;
}
