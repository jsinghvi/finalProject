package com.infy.AccountMS.DAO;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.infy.AccountMS.entity.AccountEntity;
import com.infy.AccountMS.model.Account;

public class PatientAccountDAOImpl implements PatientAccountDAO {

	@PersistenceContext
	EntityManager entityManager;

	Logger logger = LogManager.getLogger(this.getClass());

	@Override
	public Account getAccountDetails(Integer personId) throws Exception {
		// TODO Auto-generated method stub
		AccountEntity accountEntity = entityManager.find(AccountEntity.class, personId);
		if (accountEntity == null) {
			logger.debug("Could not find Account with given personId : " + personId);
			return null;
		}
		Account account = new Account();
		account.setPersonId(personId);
		account.setDepartment(accountEntity.getDepartment());
		account.setDesg(accountEntity.getDesg());
		account.setSalary(accountEntity.getSalary());
		return account;
	}

}
