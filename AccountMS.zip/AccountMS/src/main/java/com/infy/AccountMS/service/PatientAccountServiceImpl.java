package com.infy.AccountMS.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

import com.infy.AccountMS.DAO.PatientAccountDAO;
import com.infy.AccountMS.model.Account;

public class PatientAccountServiceImpl implements PatientAccountService {

	@Autowired
	PatientAccountDAO patientAccountDAO;

	Logger logger = LogManager.getLogger(this.getClass());

	@Override
	public Account getAccountDetails(Integer personId) throws Exception {
		// TODO Auto-generated method stub
		Account accountToReturn = patientAccountDAO.getAccountDetails(personId);
		if (accountToReturn == null) {
			logger.debug("Received null object in service layer");
			return null;
		}
		return accountToReturn;
	}

}
