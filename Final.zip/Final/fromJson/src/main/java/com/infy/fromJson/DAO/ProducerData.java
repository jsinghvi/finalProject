package com.infy.fromJson.DAO;

import com.infy.model.Patient;

public interface ProducerData {
public Patient readData() throws Exception;
}
