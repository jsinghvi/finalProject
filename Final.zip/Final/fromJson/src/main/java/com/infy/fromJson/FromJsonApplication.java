package com.infy.fromJson;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.infy.fromJson.DAO.ProducerDataImpl;
import com.infy.fromJson.service.Publisher;

@SpringBootApplication
public class FromJsonApplication implements CommandLineRunner {

	@Autowired
	ProducerDataImpl pd;
	@Autowired
	Publisher p;
	
	public static void main(String[] args){
		SpringApplication.run(FromJsonApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		Logger logger = LoggerFactory.getLogger(this.getClass());
	      
		try {
		p.sendMessage();
		}
		catch (Exception e) {
			 logger.info(e.getMessage());
			 System.out.println("Exception occured in Producer "+e.getMessage());
		}
	}
}
