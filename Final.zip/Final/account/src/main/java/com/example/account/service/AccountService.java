package com.example.account.service;

import com.example.account.model.Account;

public interface AccountService {
	
	public Account getDetails(Integer personId) throws Exception;

}
