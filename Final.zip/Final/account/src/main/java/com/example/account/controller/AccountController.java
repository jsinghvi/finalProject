package com.example.account.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.account.model.Account;
import com.example.account.service.AccountService;

@RestController
@CrossOrigin
public class AccountController {

	@Autowired
	AccountService as;

	// Fetches call details of a specific customer
	@RequestMapping(value = "/account/{personId}", method = RequestMethod.GET)
	public Account getDetails(@PathVariable Integer personId) {
		Logger logger = LoggerFactory.getLogger(this.getClass());
		Account a= new Account();
		try {
			logger.info("Api Hitted by consumer for personId "+personId);
			
			 a=as.getDetails(personId);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
			logger.error(e.getMessage());
		}
		return a;
	}

}
