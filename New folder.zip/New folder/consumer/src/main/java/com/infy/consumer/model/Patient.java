package com.infy.consumer.model;

public class Patient {
	
    private int personId;
    private String FirstName;
    private String LastName;
    private String[] Address;
    private Long[] PhoneNo;
    public int getPersonId() {
           return personId;
    }
    public void setPersonId(int personId) {
           this.personId = personId;
    }
    public String getFirstName() {
           return FirstName;
    }
    public void setFirstName(String firstName) {
           FirstName = firstName;
    }
    public String getLastName() {
           return LastName;
    }
    public void setLastName(String lastName) {
           LastName = lastName;
    }
    public String[] getAddress() {
           return Address;
    }
    public void setAddress(String[] address) {
           Address = address;
    }
    public Long[] getPhoneNo() {
           return PhoneNo;
    }
    public void setPhoneNo(Long[] phoneNo) {
           PhoneNo = phoneNo;
    }


}
