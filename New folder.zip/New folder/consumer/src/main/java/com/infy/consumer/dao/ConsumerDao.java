package com.infy.consumer.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.infy.consumer.entity.AccountEntity;
import com.infy.consumer.entity.ConsumerEntity;
import com.infy.consumer.entity.PatientEntity;
import com.infy.consumer.model.Consumer;
import com.infy.consumer.model.Patient;

@Repository
@Transactional
public class ConsumerDao {
	@PersistenceContext
	EntityManager entity;
	
	public String savePatient(Patient patient) {
		PatientEntity patientEntity= new PatientEntity();
		patientEntity.setAddress(patient.getAddress());
		
		patientEntity.setFirstName(patient.getFirstName());
		patientEntity.setLastName(patient.getLastName());
		patientEntity.setPersonId(patient.getPersonId());
		patientEntity.setPhoneNo(patient.getPhoneNo());
		
		entity.persist(patientEntity);
		
		return "Patient Saved with id: "+patient.getPersonId();
	}

	public String saveRecord(Integer  personId) throws Exception {
		
		AccountEntity accountEntity= entity.find(AccountEntity.class, personId);
		ConsumerEntity consumerEntity= new ConsumerEntity();
		
		consumerEntity.setPersonid(accountEntity.getPersonId());
		consumerEntity.setDepartment(accountEntity.getDepartment());
		consumerEntity.setSalary(accountEntity.getSalary());
		consumerEntity.setDesg(accountEntity.getDesg());
		
		Integer intValue= new Integer(personId);
		int pId=intValue.intValue();
		
		PatientEntity patientEntity= entity.find(PatientEntity.class, pId);
		
		consumerEntity.setAddress(patientEntity.getAddress());
		consumerEntity.setFirstname(patientEntity.getFirstName());
		consumerEntity.setLastname(patientEntity.getLastName());
		consumerEntity.setPhoneNo(patientEntity.getPhoneNo());
		
		
		
		entity.persist(consumerEntity);
		
		
		
		return "Record saved with patient Id: "+personId;
		
	}
}
